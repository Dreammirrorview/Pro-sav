"""
Equity OS Language System
Custom language interpreter and converter
a-z ↔ 0-26 ↔ 0-0²⁶, Number system converter
Copyright © 2024 Olawale Abdul-Ganiyu
"""

import re
from typing import Dict, List, Any, Optional

class EquityLanguageSystem:
    """
    Custom language system with unique encoding
    a-z interpreted as a-z, can convert to 0-26 and 0-0²⁶
    Number system: 10 is *1, 100 is *2, 1000 is *3, etc.
    """
    
    def __init__(self):
        self.language_name = "Equity Language"
        self.letter_to_number = {chr(97 + i): i for i in range(26)}  # a=0, b=1, ..., z=25
        self.number_to_letter = {i: chr(97 + i) for i in range(26)}  # 0=a, 1=b, ..., 25=z
        
    def letter_to_base26(self, letter: str) -> int:
        """Convert single letter to base-26 number (a=0, b=1, ..., z=25)"""
        letter_lower = letter.lower()
        if len(letter_lower) != 1 or letter_lower not in self.letter_to_number:
            raise ValueError(f"Invalid letter: {letter}")
        return self.letter_to_number[letter_lower]
    
    def base26_to_letter(self, number: int) -> str:
        """Convert base-26 number to letter (0=a, 1=b, ..., 25=z)"""
        if number < 0 or number > 25:
            raise ValueError(f"Number must be between 0 and 25, got: {number}")
        return self.number_to_letter[number]
    
    def text_to_base26(self, text: str) -> List[int]:
        """Convert text to base-26 number sequence"""
        base26_sequence = []
        for char in text.lower():
            if char in self.letter_to_number:
                base26_sequence.append(self.letter_to_number[char])
        return base26_sequence
    
    def base26_to_text(self, base26_sequence: List[int]) -> str:
        """Convert base-26 number sequence to text"""
        text = ""
        for number in base26_sequence:
            if 0 <= number <= 25:
                text += self.number_to_letter[number]
        return text
    
    def text_to_custom_notation(self, text: str) -> str:
        """
        Convert text to custom notation 0-0²⁶
        Example: 'ab' becomes '0-1', 'xyz' becomes '23-24-25'
        """
        base26_sequence = self.text_to_base26(text)
        return "-".join(f"0-{num}" for num in base26_sequence)
    
    def custom_notation_to_text(self, notation: str) -> str:
        """
        Convert custom notation 0-0²⁶ to text
        Example: '0-1' becomes 'ab', '23-24-25' becomes 'xyz'
        """
        # Parse notation like "0-1" or "0-5-0-10"
        parts = notation.split("-")
        base26_sequence = []
        
        for i in range(0, len(parts), 2):
            if i + 1 < len(parts):
                # This is a 0-N pattern
                try:
                    num = int(parts[i + 1])
                    base26_sequence.append(num)
                except ValueError:
                    continue
            elif parts[i].isdigit():
                # Single number
                try:
                    num = int(parts[i])
                    base26_sequence.append(num)
                except ValueError:
                    continue
        
        return self.base26_to_text(base26_sequence)
    
    def number_to_star_notation(self, number: int) -> str:
        """
        Convert number to star notation
        10=*1, 100=*2, 1000=*3, 10000=*4, etc.
        """
        if number < 10:
            return str(number)
        
        # Find the power of 10
        power = 0
        temp = number
        while temp >= 10:
            temp //= 10
            power += 1
        
        # Check if it's exactly 10^power
        if number == 10 ** power:
            return f"*{power}"
        else:
            # For numbers like 150, return 15*1
            if number < 100:
                return f"{number//10}*1"
            elif number < 1000:
                return f"{number//100}*2"
            elif number < 10000:
                return f"{number//1000}*3"
            else:
                # For larger numbers, use the star notation
                coefficient = number // (10 ** power)
                return f"{coefficient}*{power}"
    
    def star_notation_to_number(self, notation: str) -> int:
        """
        Convert star notation to number
        *1=10, *2=100, *3=1000, 15*1=150, etc.
        """
        # Handle regular numbers
        if "*" not in notation:
            return int(notation)
        
        # Parse star notation
        match = re.match(r'^(\d+)?\*(\d+)$', notation.strip())
        if not match:
            raise ValueError(f"Invalid star notation: {notation}")
        
        coefficient = match.group(1)
        power = int(match.group(2))
        
        if coefficient is None:
            # Simple notation like *3
            return 10 ** power
        else:
            # Coefficient notation like 15*1
            coeff = int(coefficient)
            return coeff * (10 ** power)
    
    def interpret_number(self, number_str: str) -> Dict[str, Any]:
        """
        Interpret number in Equity number system
        1 is 1, 10 is *1, 100 is *2, etc.
        """
        try:
            # First try to convert from star notation
            if "*" in number_str:
                number = self.star_notation_to_number(number_str)
                star_form = number_str
            else:
                number = int(number_str)
                star_form = self.number_to_star_notation(number)
            
            # Determine the interpretation
            if number < 10:
                interpretation = "single_digit"
            elif number < 100:
                interpretation = "tens"
            elif number < 1000:
                interpretation = "hundreds"
            elif number < 10000:
                interpretation = "thousands"
            elif number < 100000:
                interpretation = "ten_thousands"
            elif number < 1000000:
                interpretation = "hundred_thousands"
            elif number < 1000000000:
                interpretation = "millions"
            elif number < 1000000000000:
                interpretation = "billions"
            else:
                interpretation = "trillions_plus"
            
            return {
                "original": number_str,
                "decimal_value": number,
                "star_notation": star_form,
                "interpretation": interpretation,
                "valid": True
            }
            
        except Exception as e:
            return {
                "original": number_str,
                "error": str(e),
                "valid": False
            }
    
    def convert_language(self, text: str, target_format: str) -> Dict[str, Any]:
        """
        Convert text to different formats
        Formats: text, base26, custom_notation, star_notation
        """
        result = {
            "original_text": text,
            "target_format": target_format,
            "converted": False,
            "output": None,
            "error": None
        }
        
        try:
            if target_format == "base26":
                result["output"] = self.text_to_base26(text)
                result["converted"] = True
            elif target_format == "custom_notation":
                result["output"] = self.text_to_custom_notation(text)
                result["converted"] = True
            elif target_format == "star_notation":
                # Convert each word to star notation
                words = text.split()
                star_words = []
                for word in words:
                    if word.isdigit():
                        star_words.append(self.number_to_star_notation(int(word)))
                    else:
                        star_words.append(word)
                result["output"] = " ".join(star_words)
                result["converted"] = True
            elif target_format == "text":
                # Try to convert from any notation to text
                if "-" in text:
                    result["output"] = self.custom_notation_to_text(text)
                else:
                    result["output"] = text
                result["converted"] = True
            else:
                result["error"] = f"Unknown target format: {target_format}"
                
        except Exception as e:
            result["error"] = str(e)
        
        return result


def main():
    """Test the language system"""
    print("\n" + "="*60)
    print("EQUITY OS LANGUAGE SYSTEM")
    print("="*60)
    
    lang = EquityLanguageSystem()
    
    # Test letter conversion
    print(f"\nLetter Conversion:")
    print(f"  'a' to base-26: {lang.letter_to_base26('a')}")
    print(f"  'z' to base-26: {lang.letter_to_base26('z')}")
    print(f"  0 to letter: {lang.base26_to_letter(0)}")
    print(f"  25 to letter: {lang.base26_to_letter(25)}")
    
    # Test text conversion
    print(f"\nText Conversion:")
    text = "equity"
    base26 = lang.text_to_base26(text)
    print(f"  '{text}' to base-26: {base26}")
    print(f"  base-26 to text: {lang.base26_to_text(base26)}")
    
    # Test custom notation
    print(f"\nCustom Notation:")
    notation = lang.text_to_custom_notation("hello")
    print(f"  'hello' to notation: {notation}")
    print(f"  notation to text: {lang.custom_notation_to_text(notation)}")
    
    # Test star notation
    print(f"\nStar Notation:")
    numbers = [1, 10, 100, 1000, 10000, 150, 2500]
    for num in numbers:
        star = lang.number_to_star_notation(num)
        print(f"  {num} -> {star}")
    
    # Test number interpretation
    print(f"\nNumber Interpretation:")
    test_numbers = ["1", "10", "*1", "100", "*2", "*3", "150"]
    for num_str in test_numbers:
        interpretation = lang.interpret_number(num_str)
        print(f"  {num_str}: {interpretation['interpretation']} (value: {interpretation.get('decimal_value', 'N/A')})")


if __name__ == "__main__":
    main()