"""
Convert Legal Documents to PDF Format
For download and reference purposes
Copyright © 2024 Olawale Abdul-Ganiyu
"""

import os
import subprocess
from legal_documents import EquityLegalDocuments

class LegalDocumentConverter:
    """
    Convert legal documents to PDF and JPEG formats
    For easy download and reference
    """
    
    def __init__(self):
        self.legal = EquityLegalDocuments()
        self.output_dir = "equity_os/legal/docs"
        os.makedirs(self.output_dir, exist_ok=True)
        
    def create_pdf_from_text(self, text: str, filename: str) -> bool:
        """
        Create PDF from text using markdown to PDF conversion
        """
        try:
            # First, create a markdown file
            md_filename = filename.replace('.pdf', '.md')
            md_path = os.path.join(self.output_dir, md_filename)
            
            # Convert text to markdown format
            markdown_text = f"""# {filename.replace('.pdf', '').replace('_', ' ').title()}

{text.replace('╔', '').replace('║', '').replace('╚', '').replace('═', '')}
"""
            
            with open(md_path, 'w', encoding='utf-8') as f:
                f.write(markdown_text)
            
            # Try to convert to PDF using available tools
            pdf_path = os.path.join(self.output_dir, filename)
            
            # Try pandoc first
            try:
                subprocess.run(
                    ['pandoc', md_path, '-o', pdf_path],
                    check=True,
                    capture_output=True
                )
                return True
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass
            
            # Try wkhtmltopdf with HTML
            html_filename = filename.replace('.pdf', '.html')
            html_path = os.path.join(self.output_dir, html_filename)
            
            html_content = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{filename}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 40px; }}
        h1 {{ color: #333; border-bottom: 2px solid #333; }}
        pre {{ white-space: pre-wrap; font-family: monospace; background: #f5f5f5; padding: 20px; }}
    </style>
</head>
<body>
    <h1>{filename.replace('.pdf', '').replace('_', ' ').title()}</h1>
    <pre>{text}</pre>
</body>
</html>
"""
            
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            try:
                subprocess.run(
                    ['wkhtmltopdf', html_path, pdf_path],
                    check=True,
                    capture_output=True
                )
                return True
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass
            
            # If PDF conversion fails, at least we have the text and HTML files
            print(f"Note: PDF conversion not available, but HTML and text files created")
            return False
            
        except Exception as e:
            print(f"Error creating PDF: {e}")
            return False
    
    def generate_all_pdfs(self):
        """Generate PDF versions of all legal documents"""
        documents = self.legal.export_documents()
        
        print("\nGenerating PDF documents...")
        
        results = {}
        for doc_type, content in documents.items():
            filename = f"{doc_type}_document.pdf"
            success = self.create_pdf_from_text(content, filename)
            results[doc_type] = success
            status = "✓" if success else "○"
            print(f"{status} {filename}")
        
        return results
    
    def create_download_package(self):
        """Create a package of all legal documents"""
        print("\nCreating download package...")
        
        # List all generated files
        files = os.listdir(self.output_dir)
        print(f"\nAvailable documents in {self.output_dir}:")
        for file in files:
            file_path = os.path.join(self.output_dir, file)
            size = os.path.getsize(file_path)
            print(f"  - {file} ({size} bytes)")


def main():
    """Generate PDF legal documents"""
    print("\n" + "="*60)
    print("EQUITY OS LEGAL DOCUMENTS - PDF GENERATOR")
    print("="*60)
    
    converter = LegalDocumentConverter()
    
    # Generate all PDFs
    results = converter.generate_all_pdfs()
    
    # Create download package
    converter.create_download_package()
    
    print("\n✓ Legal documents generated successfully")
    print("  Documents are available for download and reference")


if __name__ == "__main__":
    main()