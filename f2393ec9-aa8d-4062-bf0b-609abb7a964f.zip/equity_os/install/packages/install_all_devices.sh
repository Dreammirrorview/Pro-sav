#!/bin/bash
# Equity OS Universal Installer
# Automatically detects device type and installs appropriate package
# Copyright © 2024 Olawale Abdul-Ganiyu

echo "=========================================="
echo "  EQUITY OS UNIVERSAL INSTALLER"
echo "  Copyright © 2024 Olawale Abdul-Ganiyu"
echo "=========================================="
echo ""

# Detect operating system
OS_TYPE=$(uname -s)
echo "Detected OS: $OS_TYPE"

# Detect device type
echo ""
echo "Select your device type:"
echo "1. Computer (Desktop/Laptop)"
echo "2. Tablet"
echo "3. Mobile/Phone"
echo "4. Android"
echo "5. Apple/iOS"
echo "6. Tesla"
echo "7. Zinex"
echo "8. Symbian"
echo "9. Memory Device"
echo "10. Motherboard"
echo "11. Brain Box (Automotive)"
echo "12. Human Robot"
echo "13. Other Gadget"
echo ""

read -p "Enter your choice (1-13): " device_choice

# Map choice to device type
case $device_choice in
    1) DEVICE_TYPE="computer" ;;
    2) DEVICE_TYPE="tablet" ;;
    3) DEVICE_TYPE="mobile" ;;
    4) DEVICE_TYPE="android" ;;
    5) DEVICE_TYPE="apple" ;;
    6) DEVICE_TYPE="tesla" ;;
    7) DEVICE_TYPE="zinex" ;;
    8) DEVICE_TYPE="symbian" ;;
    9) DEVICE_TYPE="memory_device" ;;
    10) DEVICE_TYPE="motherboard" ;;
    11) DEVICE_TYPE="brain_box" ;;
    12) DEVICE_TYPE="human_robot" ;;
    13) DEVICE_TYPE="other_gadget" ;;
    *) 
        echo "Invalid choice. Defaulting to 'computer'"
        DEVICE_TYPE="computer"
        ;;
esac

echo ""
echo "Selected device type: $DEVICE_TYPE"
echo ""

# Check for installation script
INSTALL_SCRIPT="install_${DEVICE_TYPE}.sh"

if [ ! -f "$INSTALL_SCRIPT" ]; then
    echo "Error: Installation script not found for $DEVICE_TYPE"
    echo "Available scripts:"
    ls -1 install_*.sh 2>/dev/null || echo "No installation scripts found"
    exit 1
fi

# Request admin code
echo "Please enter your admin installation code:"
read -s admin_code
echo ""

if [ -z "$admin_code" ]; then
    echo "Error: Admin code is required for installation"
    exit 1
fi

# Run installation
echo ""
echo "Starting Equity OS installation for $DEVICE_TYPE..."
echo ""

# Check if running with sudo/admin privileges
if [ "$OS_TYPE" = "Linux" ] || [ "$OS_TYPE" = "Darwin" ]; then
    if [ "$EUID" -ne 0 ]; then
        echo "Note: Some operations may require admin privileges"
    fi
fi

# Execute installation script
bash "$INSTALL_SCRIPT"

echo ""
echo "=========================================="
echo "  INSTALLATION COMPLETE"
echo "=========================================="
echo ""
echo "Equity OS has been installed on your $DEVICE_TYPE device"
echo ""
echo "To run Equity OS, execute: python3 equity_os.py"
echo ""
echo "To uninstall, run: /equity_os/uninstall.sh"
echo ""
echo "Thank you for using Equity OS!"
echo "Copyright © 2024 Olawale Abdul-Ganiyu"