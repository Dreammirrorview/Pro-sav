// Robot Memory Control System - Node.js Backend Server
// Developer: Olawale Abdul-ganiyu

const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
const path = require('path');

// Initialize Express app
const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// System State
const systemState = {
    status: 'online',
    battery: 85,
    speed: 0,
    temperature: 25,
    gear: 'P',
    autopilot: false,
    ownerAuthenticated: true,
    destination: null,
    sensors: {
        cameras: 8,
        radar: 4,
        lidar: 1,
        ultrasonic: 12
    },
    health: {
        energy: 98,
        powertrain: 100,
        thermal: 95,
        safety: 100
    }
};

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/api/status', (req, res) => {
    res.json(systemState);
});

app.post('/api/command', (req, res) => {
    const { command, params } = req.body;
    
    try {
        const result = executeCommand(command, params);
        res.json({ success: true, result });
    } catch (error) {
        res.status(400).json({ success: false, error: error.message });
    }
});

app.post('/api/voice', (req, res) => {
    const { voiceData } = req.body;
    
    // Process voice command
    const response = processVoiceCommand(voiceData);
    
    res.json({ success: true, response });
});

app.post('/api/security/validate', (req, res) => {
    const { type, data } = req.body;
    
    // Validate security credentials
    const isValid = validateSecurity(type, data);
    
    res.json({ success: true, isValid });
});

app.get('/api/diagnostic', (req, res) => {
    const diagnostic = runSystemDiagnostic();
    res.json({ success: true, diagnostic });
});

// Socket.IO connection handling
io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Send current system state
    socket.emit('system-state', systemState);
    
    // Handle commands from client
    socket.on('command', (data) => {
        const { command, params } = data;
        try {
            const result = executeCommand(command, params);
            socket.emit('command-result', { success: true, result });
            
            // Broadcast state change to all clients
            io.emit('system-state', systemState);
        } catch (error) {
            socket.emit('command-result', { success: false, error: error.message });
        }
    });
    
    // Handle voice commands
    socket.on('voice-command', (data) => {
        const response = processVoiceCommand(data.voiceData);
        socket.emit('voice-response', { response });
    });
    
    // Handle security validation
    socket.on('security-validate', (data) => {
        const isValid = validateSecurity(data.type, data.data);
        socket.emit('security-result', { isValid });
    });
    
    // Handle disconnection
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
});

// Command execution function
function executeCommand(command, params) {
    console.log(`Executing command: ${command}`, params);
    
    switch (command) {
        case 'start-engine':
            systemState.status = 'running';
            return { message: 'Engine started successfully' };
            
        case 'stop-engine':
            systemState.status = 'stopped';
            systemState.speed = 0;
            return { message: 'Engine stopped successfully' };
            
        case 'set-gear':
            systemState.gear = params.gear;
            return { message: `Gear changed to ${params.gear}` };
            
        case 'set-speed':
            systemState.speed = params.speed;
            return { message: `Speed set to ${params.speed} km/h` };
            
        case 'activate-autopilot':
            systemState.autopilot = true;
            return { message: 'Autopilot activated' };
            
        case 'deactivate-autopilot':
            systemState.autopilot = false;
            return { message: 'Autopilot deactivated' };
            
        case 'set-destination':
            systemState.destination = params.destination;
            return { message: `Destination set to ${params.destination}` };
            
        case 'emergency-stop':
            systemState.speed = 0;
            systemState.autopilot = false;
            return { message: 'Emergency stop executed' };
            
        case 'run-diagnostic':
            const diagnostic = runSystemDiagnostic();
            return { message: 'Diagnostic completed', diagnostic };
            
        default:
            throw new Error(`Unknown command: ${command}`);
    }
}

// Voice command processing
function processVoiceCommand(voiceData) {
    // Simulate voice processing
    const commands = voiceData.toLowerCase();
    
    if (commands.includes('start engine') || commands.includes('start the engine')) {
        return 'Starting engine. All systems operational.';
    } else if (commands.includes('stop engine') || commands.includes('stop the engine')) {
        return 'Stopping engine. Shutting down safely.';
    } else if (commands.includes('autopilot') || commands.includes('auto pilot')) {
        return 'Autopilot activated. I am now in control of the vehicle.';
    } else if (commands.includes('destination')) {
        return 'Please specify your destination for navigation.';
    } else if (commands.includes('emergency') || commands.includes('stop')) {
        return 'Emergency stop initiated. Vehicle coming to complete stop.';
    } else if (commands.includes('diagnostic') || commands.includes('check')) {
        return 'Running system diagnostic. Please wait for results.';
    } else {
        return 'I understood your request. How may I assist you further?';
    }
}

// Security validation
function validateSecurity(type, data) {
    // Simulate security validation
    switch (type) {
        case 'voice':
            return data && data.length > 0;
            
        case 'face':
            return data && data.confidence > 0.95;
            
        case 'fingerprint':
            return data && data.matchScore > 0.98;
            
        default:
            return false;
    }
}

// System diagnostic
function runSystemDiagnostic() {
    const diagnostic = {
        timestamp: new Date().toISOString(),
        systems: {
            energy: {
                status: 'healthy',
                health: systemState.health.energy,
                details: {
                    batteryLevel: systemState.battery + '%',
                    voltage: '400V',
                    temperature: systemState.temperature + '°C'
                }
            },
            powertrain: {
                status: 'healthy',
                health: systemState.health.powertrain,
                details: {
                    motorStatus: 'operational',
                    inverterStatus: 'functional',
                    transmissionStatus: 'ready'
                }
            },
            thermal: {
                status: 'healthy',
                health: systemState.health.thermal,
                details: {
                    batteryTemp: systemState.temperature + '°C',
                    motorTemp: '35°C',
                    coolantTemp: '23°C'
                }
            },
            safety: {
                status: 'healthy',
                health: systemState.health.safety,
                details: {
                    collisionDetection: 'active',
                    emergencyBraking: 'ready',
                    airbags: 'armed'
                }
            }
        },
        errors: [
            {
                code: 'W001',
                severity: 'warning',
                description: 'Low tire pressure - Front Left',
                solution: 'Inflate to 32 PSI'
            }
        ],
        recommendations: [
            'Check tire pressure for all wheels',
            'Schedule battery health check in 30 days',
            'Consider updating vehicle software'
        ]
    };
    
    return diagnostic;
}

// System monitoring
setInterval(() => {
    // Update battery level
    systemState.battery = Math.max(0, Math.min(100, 
        systemState.battery + (Math.random() - 0.5) * 0.5
    ));
    
    // Update temperature
    systemState.temperature = Math.max(15, Math.min(40,
        systemState.temperature + (Math.random() - 0.5) * 0.2
    ));
    
    // Broadcast state changes
    io.emit('system-state', systemState);
}, 5000);

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log('=================================================');
    console.log('Robot Memory Control System - Server Started');
    console.log('Developer: Olawale Abdul-ganiyu');
    console.log('=================================================');
    console.log(`Server running on port ${PORT}`);
    console.log(`Access the system at: http://localhost:${PORT}`);
    console.log('=================================================');
    console.log('System Features:');
    console.log('- Autonomous driving controls');
    console.log('- Voice command processing');
    console.log('- Security and authentication');
    console.log('- Real-time system monitoring');
    console.log('- Diagnostic and maintenance');
    console.log('=================================================');
});

module.exports = { app, server, io };