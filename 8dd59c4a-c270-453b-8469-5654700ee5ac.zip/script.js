// Robot Memory Control System - Main JavaScript
// Developer: Olawale Abdul-ganiyu

// System State
const robotSystem = {
    status: 'online',
    battery: 85,
    speed: 0,
    temperature: 25,
    destination: null,
    autopilot: false,
    gear: 'P',
    ownerAuthenticated: true,
    voiceActive: false,
    securityLevel: 'high'
};

// Initialize System
document.addEventListener('DOMContentLoaded', function() {
    updateTime();
    setInterval(updateTime, 1000);
    initializeNavigation();
    initializeVoiceCommand();
    initializeSensors();
    startSystemMonitoring();
    
    console.log('Robot Memory Control System initialized');
    console.log('Developer: Olawale Abdul-ganiyu');
});

// Update Time Display
function updateTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    document.getElementById('currentTime').textContent = timeString;
}

// Initialize Navigation System
function initializeNavigation() {
    const navButtons = document.querySelectorAll('.nav-btn');
    navButtons.forEach(button => {
        button.addEventListener('click', function() {
            const sectionId = this.getAttribute('data-section');
            showSection(sectionId);
            
            // Update active state
            navButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

// Show Section
function showSection(sectionId) {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach(section => {
        section.classList.remove('active');
    });
    
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    }
}

// Voice Command System
function initializeVoiceCommand() {
    const voiceBtn = document.getElementById('voiceBtn');
    const voiceResult = document.getElementById('voiceResult');
    
    voiceBtn.addEventListener('click', function() {
        if (!robotSystem.voiceActive) {
            startVoiceRecognition();
        } else {
            stopVoiceRecognition();
        }
    });
}

function startVoiceRecognition() {
    robotSystem.voiceActive = true;
    const voiceBtn = document.getElementById('voiceBtn');
    const voiceText = voiceBtn.querySelector('.voice-text');
    
    voiceText.textContent = 'Listening...';
    voiceBtn.style.background = 'linear-gradient(135deg, #ff4444 0%, #ff6b6b 100%)';
    
    // Simulate voice recognition (replace with actual Web Speech API)
    setTimeout(() => {
        const responses = [
            "Good day! I am ready to assist you. Please fasten your seatbelt and tell me where you would like to go.",
            "Hello! All systems are functioning perfectly. How may I help you today?",
            "Welcome back! The vehicle is ready for your journey. Where shall we go?"
        ];
        const randomResponse = responses[Math.floor(Math.random() * responses.length)];
        displayVoiceResponse(randomResponse);
        stopVoiceRecognition();
    }, 2000);
}

function stopVoiceRecognition() {
    robotSystem.voiceActive = false;
    const voiceBtn = document.getElementById('voiceBtn');
    const voiceText = voiceBtn.querySelector('.voice-text');
    
    voiceText.textContent = 'Tap to Speak';
    voiceBtn.style.background = 'linear-gradient(135deg, #00d4ff 0%, #0066cc 100%)';
}

function displayVoiceResponse(text) {
    const voiceResult = document.getElementById('voiceResult');
    voiceResult.innerHTML = `<p>Robot: "${text}"</p>`;
}

// Sensor Initialization
function initializeSensors() {
    console.log('Initializing sensor array...');
    
    // Simulate sensor activation
    const sensors = {
        cameras: 8,
        radar: 4,
        lidar: 1,
        ultrasonic: 12
    };
    
    console.log('Sensors initialized:', sensors);
}

// System Monitoring
function startSystemMonitoring() {
    setInterval(() => {
        updateBatteryLevel();
        updateTemperature();
        checkSystemHealth();
    }, 5000);
}

function updateBatteryLevel() {
    // Simulate battery fluctuation
    const fluctuation = (Math.random() - 0.5) * 0.5;
    robotSystem.battery = Math.max(0, Math.min(100, robotSystem.battery + fluctuation));
    
    // Update display
    const batteryElements = document.querySelectorAll('.battery-level');
    batteryElements.forEach(el => {
        el.textContent = robotSystem.battery.toFixed(1) + '%';
    });
}

function updateTemperature() {
    // Simulate temperature changes
    const fluctuation = (Math.random() - 0.5) * 0.2;
    robotSystem.temperature = Math.max(15, Math.min(40, robotSystem.temperature + fluctuation));
}

function checkSystemHealth() {
    // Simulate system health checks
    const systems = ['energy', 'powertrain', 'thermal', 'safety'];
    
    systems.forEach(system => {
        const health = Math.random() * 5 + 95; // 95-100% health
        console.log(`${system} system health: ${health.toFixed(1)}%`);
    });
}

// Quick Actions
function startEngine() {
    if (robotSystem.gear === 'P') {
        robotSystem.status = 'running';
        displayVoiceResponse('Engine started. All systems are operational. Please select your destination.');
        console.log('Engine started successfully');
    } else {
        displayVoiceResponse('Please put the vehicle in Park before starting the engine.');
    }
}

function openDoor() {
    if (robotSystem.ownerAuthenticated) {
        displayVoiceResponse('Door opened. Please enter safely.');
        console.log('Door opened');
    } else {
        displayVoiceResponse('Authentication required to open door.');
    }
}

function setDestination() {
    const destination = prompt('Enter your destination:');
    if (destination) {
        robotSystem.destination = destination;
        document.getElementById('destination').textContent = destination;
        
        // Simulate route calculation
        const distance = Math.floor(Math.random() * 50 + 5);
        const eta = Math.floor(distance / 60 * 60); // rough estimate
        
        document.getElementById('distance').textContent = distance + ' km';
        document.getElementById('eta').textContent = formatTime(eta);
        
        displayVoiceResponse(`Destination set to ${destination}. Estimated travel time: ${Math.floor(eta/60)} minutes. Traffic is light. Ready to begin journey.`);
    }
}

function formatTime(minutes) {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
        return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
}

function activateAutoPilot() {
    if (!robotSystem.autopilot) {
        robotSystem.autopilot = true;
        document.getElementById('autopilotStatus').textContent = 'Active';
        document.getElementById('autopilotStatus').className = 'status-on';
        displayVoiceResponse('Auto pilot activated. I am now in full control of the vehicle. Relax and enjoy the ride.');
        console.log('Auto pilot activated');
    } else {
        displayVoiceResponse('Auto pilot is already active.');
    }
}

function deactivateAutoPilot() {
    if (robotSystem.autopilot) {
        robotSystem.autopilot = false;
        document.getElementById('autopilotStatus').textContent = 'Inactive';
        document.getElementById('autopilotStatus').className = 'status-off';
        displayVoiceResponse('Auto pilot deactivated. You now have manual control.');
        console.log('Auto pilot deactivated');
    }
}

function emergencyStop() {
    robotSystem.speed = 0;
    robotSystem.autopilot = false;
    document.getElementById('autopilotStatus').textContent = 'Inactive';
    document.getElementById('autopilotStatus').className = 'status-off';
    displayVoiceResponse('EMERGENCY STOP ACTIVATED! Vehicle has come to a complete stop. All systems are safe.');
    console.log('Emergency stop executed');
}

function runDiagnostic() {
    displayVoiceResponse('Running full system diagnostic... Please wait.');
    
    setTimeout(() => {
        const results = [
            'Energy System: All systems normal',
            'Powertrain: Operating at 100% efficiency',
            'Thermal System: Temperature optimal',
            'Safety Systems: All functional',
            'Sensors: All 25 sensors active and calibrated'
        ];
        
        let resultText = 'Diagnostic complete. Results:\n';
        results.forEach(result => {
            resultText += '• ' + result + '\n';
        });
        
        displayVoiceResponse(resultText);
        console.log('Diagnostic completed');
    }, 3000);
}

// Gear Selection
function selectGear(gear) {
    robotSystem.gear = gear;
    
    // Update display
    const gearDisplay = document.querySelector('.gear-display');
    if (gearDisplay) {
        gearDisplay.textContent = gear;
        
        // Change color based on gear
        if (gear === 'D') {
            gearDisplay.style.color = '#00ff88';
        } else if (gear === 'R') {
            gearDisplay.style.color = '#ff4444';
        } else {
            gearDisplay.style.color = '#00d4ff';
        }
    }
    
    console.log(`Gear changed to ${gear}`);
}

// Navigation Functions
function calculateRoute() {
    const destination = document.getElementById('destinationInput').value;
    if (destination) {
        robotSystem.destination = destination;
        
        // Simulate route calculation
        const routeInfo = document.getElementById('routeInfo');
        routeInfo.innerHTML = `
            <div style="margin-bottom: 10px;">
                <strong>📍 Destination:</strong> ${destination}
            </div>
            <div style="margin-bottom: 10px;">
                <strong>📏 Distance:</strong> ${Math.floor(Math.random() * 50 + 5)} km
            </div>
            <div style="margin-bottom: 10px;">
                <strong>⏱️ Estimated Time:</strong> ${Math.floor(Math.random() * 40 + 10)} minutes
            </div>
            <div style="margin-bottom: 10px;">
                <strong>🚦 Traffic:</strong> Light
            </div>
            <div>
                <strong>🛣️ Route:</strong> Optimal route selected
            </div>
        `;
        
        displayVoiceResponse(`Route calculated to ${destination}. Traffic is light. Ready to begin journey.`);
    } else {
        displayVoiceResponse('Please enter a destination first.');
    }
}

// Lane Change Functions
function changeLaneLeft() {
    if (robotSystem.autopilot) {
        displayVoiceResponse('Changing to left lane. Checking surroundings... Lane change complete.');
        console.log('Lane changed left');
    } else {
        displayVoiceResponse('Auto pilot must be active for lane changes.');
    }
}

function changeLaneRight() {
    if (robotSystem.autopilot) {
        displayVoiceResponse('Changing to right lane. Checking surroundings... Lane change complete.');
        console.log('Lane changed right');
    } else {
        displayVoiceResponse('Auto pilot must be active for lane changes.');
    }
}

// Security Functions
function trainVoice() {
    displayVoiceResponse('Voice training initiated. Please speak clearly for 10 seconds...');
    
    setTimeout(() => {
        displayVoiceResponse('Voice training complete. Your voice has been registered successfully.');
        console.log('Voice trained');
    }, 3000);
}

function authorizeVoice() {
    displayVoiceResponse('To authorize another voice, please have them speak clearly for 10 seconds...');
    
    setTimeout(() => {
        displayVoiceResponse('New voice authorized successfully. They can now operate the vehicle.');
        console.log('New voice authorized');
    }, 3000);
}

function registerFace() {
    displayVoiceResponse('Position your face in front of the camera. Keeping still...');
    
    setTimeout(() => {
        displayVoiceResponse('Face registered successfully. Facial recognition is now active.');
        console.log('Face registered');
    }, 3000);
}

function scanFace() {
    displayVoiceResponse('Scanning face... Face recognized. Access granted.');
    console.log('Face scanned');
}

function registerFingerprint() {
    displayVoiceResponse('Place your finger on the fingerprint scanner...');
    
    setTimeout(() => {
        displayVoiceResponse('Fingerprint registered successfully.');
        console.log('Fingerprint registered');
    }, 2000);
}

function scanFingerprint() {
    displayVoiceResponse('Scanning fingerprint... Fingerprint recognized. Access granted.');
    console.log('Fingerprint scanned');
}

// Diagnostic Functions
function findSolution() {
    const problem = document.getElementById('problemInput').value;
    if (problem) {
        const solutionResult = document.getElementById('solutionResult');
        solutionResult.innerHTML = `
            <div style="margin-bottom: 10px;">
                <strong>Problem:</strong> ${problem}
            </div>
            <div style="margin-bottom: 10px;">
                <strong>Searching Google...</strong>
            </div>
            <div style="margin-bottom: 10px;">
                <strong>Solution Found:</strong>
            </div>
            <p>Based on the problem description, here are recommended solutions:</p>
            <ol style="margin-left: 20px; margin-top: 10px;">
                <li>Check the affected component for visible damage</li>
                <li>Review system diagnostic logs for error codes</li>
                <li>Consult vehicle manual for troubleshooting steps</li>
                <li>Contact authorized service center if problem persists</li>
            </ol>
            <p style="margin-top: 10px; font-style: italic;">Additional resources from Google search have been integrated into the solution database.</p>
        `;
        
        displayVoiceResponse(`I have analyzed the problem "${problem}" and found potential solutions. Please check the solution finder for detailed recommendations.`);
    } else {
        displayVoiceResponse('Please describe the problem first.');
    }
}

// Entertainment Functions
function playMusic() {
    displayVoiceResponse('Music player activated. What would you like to listen to?');
}

function openRadio() {
    displayVoiceResponse('Radio activated. Scanning for available stations...');
}

function openBrowser() {
    displayVoiceResponse('Browser opened. You can now search the internet for information.');
}

// Climate Control Functions
function setTemperature(temp) {
    displayVoiceResponse(`Climate control set to ${temp}°C. Adjusting cabin temperature...`);
}

function toggleAC() {
    displayVoiceResponse('Air conditioning toggled. Enjoy comfortable temperature.');
}

// Lighting Functions
function turnOnLights() {
    displayVoiceResponse('Lights turned on. All exterior and interior lights are now active.');
}

function turnOffLights() {
    displayVoiceResponse('Lights turned off. Parking lights remain active.');
}

// Window Control Functions
function openWindow(window) {
    displayVoiceResponse(`${window} window opened. Fresh air coming in.`);
}

function closeWindow(window) {
    displayVoiceResponse(`${window} window closed. Cabin sealed.`);
}

// Speed Control
function adjustSpeed(speed) {
    if (robotSystem.autopilot) {
        robotSystem.speed = speed;
        displayVoiceResponse(`Speed adjusted to ${speed} km/h. Adhering to traffic regulations.`);
    } else {
        displayVoiceResponse('Auto pilot must be active for automatic speed control.');
    }
}

// Error Handling
function handleError(error) {
    console.error('System Error:', error);
    displayVoiceResponse(`Error detected: ${error.message}. Initiating diagnostic protocols...`);
}

// System Reboot
function rebootSystem() {
    displayVoiceResponse('System reboot initiated. This will take approximately 30 seconds...');
    
    setTimeout(() => {
        displayVoiceResponse('System reboot complete. All systems are now operational.');
        console.log('System rebooted');
    }, 3000);
}

// Export functions for global access
window.robotSystem = robotSystem;
window.startEngine = startEngine;
window.openDoor = openDoor;
window.setDestination = setDestination;
window.activateAutoPilot = activateAutoPilot;
window.deactivateAutoPilot = deactivateAutoPilot;
window.emergencyStop = emergencyStop;
window.runDiagnostic = runDiagnostic;
window.selectGear = selectGear;
window.calculateRoute = calculateRoute;
window.changeLaneLeft = changeLaneLeft;
window.changeLaneRight = changeLaneRight;
window.trainVoice = trainVoice;
window.authorizeVoice = authorizeVoice;
window.registerFace = registerFace;
window.scanFace = scanFace;
window.registerFingerprint = registerFingerprint;
window.scanFingerprint = scanFingerprint;
window.findSolution = findSolution;
window.playMusic = playMusic;
window.openRadio = openRadio;
window.openBrowser = openBrowser;
window.setTemperature = setTemperature;
window.toggleAC = toggleAC;
window.turnOnLights = turnOnLights;
window.turnOffLights = turnOffLights;
window.openWindow = openWindow;
window.closeWindow = closeWindow;
window.adjustSpeed = adjustSpeed;
window.handleError = handleError;
window.rebootSystem = rebootSystem;

console.log('Robot Memory Control System JavaScript loaded successfully');
console.log('All functions are ready for use');